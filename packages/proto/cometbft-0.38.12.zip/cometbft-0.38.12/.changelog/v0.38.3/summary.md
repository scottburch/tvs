*January 17, 2024*

This release addresses a high impact security issue reported in advisory
([ASA-2024-001](https://github.com/cometbft/cometbft/security/advisories/GHSA-qr8r-m495-7hc4)).
There are other non-security bugs fixes that have been addressed since
`v0.38.2` was released, as well as some improvements.
Please check the list below for further details.

