- `[consensus]` Fix for "Validation of `VoteExtensionsEnableHeight` can cause chain halt"
  ([ASA-2024-001](https://github.com/cometbft/cometbft/security/advisories/GHSA-qr8r-m495-7hc4))
