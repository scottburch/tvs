- Bump minimum Go version to 1.20
  ([\#385](https://github.com/cometbft/cometbft/issues/385))