- `[rpc]` Fix an issue where a legacy ABCI response, created on `v0.37` or before, is not returned properly in `v0.38` and up
  on the `/block_results` RPC endpoint.
  ([\#3002](https://github.com/cometbft/cometbft/issues/3002))
