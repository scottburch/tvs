- `[blocksync]` Do not stay in blocksync if the node's validator voting power
  is high enough to block the chain while it is not online
  ([\#3406](https://github.com/cometbft/cometbft/pull/3406))
