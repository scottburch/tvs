- `[p2p]` Node respects configured `max_num_outbound_peers` limit when dialing
  peers provided by a seed node
  ([\#486](https://github.com/cometbft/cometbft/issues/486))
