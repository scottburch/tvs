- `[p2p/conn]` Update send monitor, used for sending rate limiting, once per batch of packets sent
  ([\#3382](https://github.com/cometbft/cometbft/pull/3382))
