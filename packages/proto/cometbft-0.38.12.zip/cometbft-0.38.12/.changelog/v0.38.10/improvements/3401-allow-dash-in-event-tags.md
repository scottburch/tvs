- `[libs/pubsub]` Allow dash (`-`) in event tags
  ([\#3401](https://github.com/cometbft/cometbft/issues/3401))
