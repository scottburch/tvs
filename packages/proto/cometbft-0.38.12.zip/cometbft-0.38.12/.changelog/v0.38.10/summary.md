*July 16, 2024*

This release fixes a bug in `v0.38.x` that prevented ABCI responses from being
correctly read when upgrading from `v0.37.x` or below. It also includes a few other
bug fixes and performance improvements.
