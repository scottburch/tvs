- `[indexer]` Fixed ineffective select break statements; they now
  point to their enclosing for loop label to exit
  ([\#3544](https://github.com/cometbft/cometbft/issues/3544))