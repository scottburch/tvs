- `[types]` Only check IFF vote is a non-nil Precommit if extensionsEnabled
  types ([\#3565](https://github.com/cometbft/cometbft/issues/3565))
