*July 1, 2024*

This release reverts the API-breaking change to the Mempool interface introduced in the last patch
release (v0.38.8) while still keeping the performance improvement added to the mempool. It also
includes a minor fix to the RPC endpoints /tx and /tx_search.
