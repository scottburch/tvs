- `[blocksync]` Request a block from peer B if we are approaching pool's height
  (less than 50 blocks) and the current peer A is slow in sending us the
  block [\#2475](https://github.com/cometbft/cometbft/pull/2475)
