- `[blocksync]` Request the block N from peer B immediately after getting
  `NoBlockResponse` from peer A
  [\#2475](https://github.com/cometbft/cometbft/pull/2475)
