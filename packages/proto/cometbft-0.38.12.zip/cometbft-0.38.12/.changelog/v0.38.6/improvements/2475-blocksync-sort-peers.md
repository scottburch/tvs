- `[blocksync]` Sort peers by download rate (the fastest peer is picked first)
  [\#2475](https://github.com/cometbft/cometbft/pull/2475)
