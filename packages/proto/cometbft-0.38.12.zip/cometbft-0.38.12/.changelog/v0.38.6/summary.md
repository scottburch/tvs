*March 12, 2024*

This release fixes a security bug in the light client. It also introduces many
improvements to the block sync in collaboration with the
[Osmosis](https://osmosis.zone/) team.
