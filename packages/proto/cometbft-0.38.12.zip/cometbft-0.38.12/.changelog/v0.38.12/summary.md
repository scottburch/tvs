*September 3, 2024*

This release includes a security fix for the light client and is recommended
for all users.
