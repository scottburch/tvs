- `[crypto/secp256k1]` Adjust to breaking interface changes in
  `btcec/v2` latest release, while avoiding breaking changes to
  local CometBFT functions
  ([\#3728](https://github.com/cometbft/cometbft/pull/3728))
