- `[e2e]` Add `log_format` option to manifest file
  ([#3836](https://github.com/cometbft/cometbft/issues/3836)).
