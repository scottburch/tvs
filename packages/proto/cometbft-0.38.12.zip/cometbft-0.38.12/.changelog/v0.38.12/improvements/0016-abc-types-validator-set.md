- `[types]` Check that proposer is one of the validators in `ValidateBasic`
  ([\#ASA-2024-009](https://github.com/cometbft/cometbft/security/advisories/GHSA-g5xx-c4hv-9ccc))
