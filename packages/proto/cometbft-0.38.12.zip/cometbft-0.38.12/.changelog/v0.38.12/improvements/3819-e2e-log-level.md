- `[e2e]` Add `log_level` option to manifest file
  ([#3819](https://github.com/cometbft/cometbft/pull/3819)).
