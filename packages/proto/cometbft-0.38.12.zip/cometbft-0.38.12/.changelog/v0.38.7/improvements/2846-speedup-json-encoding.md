- `[libs/json]` Lower the memory overhead of JSON encoding by using JSON encoders internally
  ([\#2846](https://github.com/cometbft/cometbft/pull/2846)).
