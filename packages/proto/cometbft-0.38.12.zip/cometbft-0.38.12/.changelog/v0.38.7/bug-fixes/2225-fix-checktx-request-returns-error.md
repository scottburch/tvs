- [`mempool`] Panic when a CheckTx request to the app returns an error
  ([\#2225](https://github.com/cometbft/cometbft/pull/2225))
