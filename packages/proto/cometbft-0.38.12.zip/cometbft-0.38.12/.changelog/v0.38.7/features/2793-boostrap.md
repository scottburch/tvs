- [`node`] Add `BootstrapStateWithGenProvider` to boostrap state using a custom
  genesis doc provider ([\#2793](https://github.com/cometbft/cometbft/pull/2793))
