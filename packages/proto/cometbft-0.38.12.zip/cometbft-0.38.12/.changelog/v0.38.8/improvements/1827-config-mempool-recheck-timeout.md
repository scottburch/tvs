- `[config]` Added `recheck_timeout` mempool parameter to set how much time to wait for recheck
  responses from the app (only applies to non-local ABCI clients).
  ([\#1827](https://github.com/cometbft/cometbft/issues/1827/))
