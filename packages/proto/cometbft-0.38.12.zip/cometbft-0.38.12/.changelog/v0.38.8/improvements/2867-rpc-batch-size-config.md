- `[rpc]` Add a configurable maximum batch size for RPC requests.
  ([\#2867](https://github.com/cometbft/cometbft/pull/2867)).
