- `[types]` Do not batch verify a commit if the validator set keys have different
  types. ([\#3195](https://github.com/cometbft/cometbft/issues/3195)
