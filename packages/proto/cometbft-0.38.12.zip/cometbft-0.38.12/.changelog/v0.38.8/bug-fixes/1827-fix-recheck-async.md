- [`mempool`] Fix data race when rechecking with async ABCI client
  ([\#1827](https://github.com/cometbft/cometbft/issues/1827))
