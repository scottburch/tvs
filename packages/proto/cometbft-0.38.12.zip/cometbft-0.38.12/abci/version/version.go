package version

import (
	"github.com/cometbft/cometbft/version"
)

// TODO: eliminate this after some version refactor

const Version = version.ABCISemVer
