---
order: 1
parent:
  title: Networks
  order: 5
---

# Overview

Use [Docker Compose](./docker-compose.md) to spin up CometBFT testnets on your
local machine.

See the `cometbft testnet --help` command for more help initializing testnets.
