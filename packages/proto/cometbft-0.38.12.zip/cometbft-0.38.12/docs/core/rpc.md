---
order: 9
---

# RPC

The RPC documentation is hosted here:

- [OpenAPI reference](../rpc)

<!--
NOTE: The OpenAPI reference (../rpc) is injected into the documentation during
the CometBFT docs build process. See https://github.com/cometbft/cometbft-docs/
for details.
-->
