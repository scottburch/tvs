---
order: false
parent:
  order: 2
---

# Guides

- [Installing CometBFT](./install.md)
- [Quick-start using CometBFT](./quick-start.md)
- [Creating a built-in application in Go](./go-built-in.md)
- [Creating an external application in Go](./go.md)
