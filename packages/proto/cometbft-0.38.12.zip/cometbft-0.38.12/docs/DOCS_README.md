# Docs Build Workflow

The documentation for CometBFT is hosted at:

- <https://docs.cometbft.com>

built from the files in these (`/docs` and `/spec`) directories.

Content modified and merged to these folders will be deployed to the `https://docs.cometbft.com` website using workflow logic from the [cometbft-docs](https://github.com/cometbft/cometbft-docs) repository

### Building locally

For information on how to build the documentation and view it locally, please visit the [cometbft-docs](https://github.com/cometbft/cometbft-docs) Github repository.
