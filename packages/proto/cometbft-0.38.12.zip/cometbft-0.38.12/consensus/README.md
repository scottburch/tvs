# Consensus

See the [consensus spec](https://github.com/cometbft/cometbft/tree/v0.38.x/spec/consensus) for more information.
